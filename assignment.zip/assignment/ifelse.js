// Program 1: Check whether a number is positive or negative
let num1 = -10;
if (num1 >= 0) {
    console.log("Number is positive");
} else {
    console.log("Number is negative");
}

// Program 2: Check whether a number is even or odd
let num2 = 7;
if (num2 % 2 === 0) {
    console.log("Even number");
} else {
    console.log("Odd number");
}

// Program 3: Check voting eligibility
let age = 16;
if (age >= 18) {
    console.log("Eligible to vote");
} else {
    console.log("Not eligible to vote");
}

// Program 4: Check pass or fail
let marks = 30;
if (marks >= 35) {
    console.log("Pass");
} else {
    console.log("Fail");
}

// Program 5: Find greater of two numbers
let a = 15;
let b = 25;
if (a > b) {
    console.log("A is greater");
} else {
    console.log("B is greater");
}

// Program 6: Check whether a year is a leap year
let year = 2023;
if (year % 4 === 0) {
    console.log("Leap year");
} else {
    console.log("Not a leap year");
}

// Program 7: Check whether a character is a vowel or consonant
let ch = 'e';
if (ch === 'a' || ch === 'e' || ch === 'i' || ch === 'o' || ch === 'u') {
    console.log("Vowel");
} else {
    console.log("Consonant");
}
