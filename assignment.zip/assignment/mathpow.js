function squareNumbers() {
  let i = 1;

  do {
    console.log("Square of", i, "=", Math.pow(i, 2));
    i++;
  } while (i <= 5);
}

squareNumbers();
