function printNumbers() {
  let i = 1;

  do {
    console.log("Number:", i);
    i++;
  } while (i <= 5);
}

printNumbers();
