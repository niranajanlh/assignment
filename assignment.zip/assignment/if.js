// Program 1: Check if a number is positive
let num1 = 10;
if (num1 > 0) {
    console.log("Number is positive");
}

// Program 2: Check if a number is negative
let num2 = -5;
if (num2 < 0) {
    console.log("Number is negative");
}

// Program 3: Check if a number is zero
let num3 = 0;
if (num3 === 0) {
    console.log("Number is zero");
}

// Program 4: Check if a person is eligible to vote
let age = 20;
if (age >= 18) {
    console.log("Eligible to vote");
}

// Program 5: Check if a number is even
let num4 = 8;
if (num4 % 2 === 0) {
    console.log("Number is even");
}

// Program 6: Check if a student has passed
let marks = 45;
if (marks >= 35) {
    console.log("Student has passed");
}

// Program 7: Check if a year is a leap year (basic condition)
let year = 2024;
if (year % 4 === 0) {
    console.log("Leap year");
}
